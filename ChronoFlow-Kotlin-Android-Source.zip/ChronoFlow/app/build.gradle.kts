plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.chronoflow.stopwatch"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.chronoflow.stopwatch"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0.0"
    }
}


dependencies {
    implementation("androidx.activity:activity-ktx:1.10.1")
}
